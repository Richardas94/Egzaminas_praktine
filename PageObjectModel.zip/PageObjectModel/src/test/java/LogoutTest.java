import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class LogoutTest extends BasePageTest {
    LoginPage loginpage = new LoginPage(driver);
    MyAccountPage myAccountPage = new MyAccountPage(driver);

    @Test
    void userCanLogout() throws InterruptedException {
        loginpage.enterInputUsername("dada");
        loginpage.enterInputPassword("123");
        loginpage.clickButtonLogin();
        WaitUtils.waitForElement(driver, myAccountPage.getLinkLogout());
        myAccountPage.clickLinkLogout();
        Assertions.assertTrue(loginpage.isHeaderOfApplicationDisplayed(), "Logout failed");
    }

}
