import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class RegisterFailTest extends BasePageTest{
    LoginPage loginPage = new LoginPage(driver);
    RegisterPage registerpage = new RegisterPage(driver);

    @Test
    void userCannotRegister() throws InterruptedException {
        loginPage.clickLinkCreateNewAccount();
        registerpage.enterInputUsername("dada123111111111111aaaa");
        registerpage.enterInputPassword("123");
        registerpage.enterInputPasswordConfirm("1234");
        registerpage.clickButtonCreateNewAcount();
        WaitUtils.waitForElement(driver, registerpage.getMessageAccountNotCreated());
        Assertions.assertTrue(registerpage.isMessageAccountNotCreatedDisplayed(),
                "Bug! Cannot register with different passwords!");
    }
}
