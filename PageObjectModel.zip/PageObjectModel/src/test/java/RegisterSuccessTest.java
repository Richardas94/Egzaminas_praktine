import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class RegisterSuccessTest extends BasePageTest {
    LoginPage loginPage = new LoginPage(driver);
    RegisterPage registerpage = new RegisterPage(driver);
    MyAccountPage myAccountPage = new MyAccountPage(driver);

    @Test
    void userCanRegister() throws InterruptedException {
        loginPage.clickLinkCreateNewAccount();
        registerpage.enterInputUsername("dada12345aaaaaasss");
        registerpage.enterInputPassword("123");
        registerpage.enterInputPasswordConfirm("123");
        registerpage.clickButtonCreateNewAcount();
        WaitUtils.waitForElement(driver, myAccountPage.getButtonCalculate());
        Assertions.assertTrue(myAccountPage.isButtonCalculateDisplayed(), "Register failed");
    }
}