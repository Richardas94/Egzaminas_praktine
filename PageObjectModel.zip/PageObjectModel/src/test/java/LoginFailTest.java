import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class LoginFailTest extends BasePageTest{
    LoginPage loginpage = new LoginPage(driver);
    MyAccountPage myAccountPage = new MyAccountPage(driver);

    @Test
    void userCannotLogin() throws InterruptedException {
        loginpage.enterInputUsername("dad12345iiiiiiiiiiiiiiiiifff");
        loginpage.enterInputPassword("123");
        loginpage.clickButtonLogin();
        WaitUtils.waitForElement(driver, loginpage.getMessageLoginFailed());
        Assertions.assertTrue(loginpage.isMessageLoginFailedDisplayed(),
                "Bug! User cannot login with not existing username or password!");
    }
}
