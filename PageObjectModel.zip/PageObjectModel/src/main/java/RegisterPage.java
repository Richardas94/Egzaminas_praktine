import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegisterPage extends BasePage {

    @FindBy(xpath = "//input[@id='username']")
    WebElement inputUsername;

    @FindBy(xpath = "//input[@id='password']")
    WebElement inputPassword;

    @FindBy(xpath = "//input[@id='passwordConfirm']")
    WebElement inputPasswordConfirm;

    @FindBy(xpath = "//button[@type='submit']")
    WebElement buttonCreateNewAccount;

    @FindBy(xpath = "//span[@id='passwordConfirm.errors']")
    WebElement messageAccountPasswordsDoNotMatch;


    public RegisterPage(WebDriver driver) {
        super(driver);
    }

    public void enterInputUsername(String username) {
        inputUsername.sendKeys(username);
    }

    public void enterInputPassword(String password) {
        inputPassword.sendKeys(password);
    }

    public void enterInputPasswordConfirm(String password) {
        inputPasswordConfirm.sendKeys(password);
    }

    public void clickButtonCreateNewAcount() {
        buttonCreateNewAccount.click();
    }

    public WebElement getMessageAccountNotCreated() {
        return messageAccountPasswordsDoNotMatch;
    }

    public boolean isMessageAccountNotCreatedDisplayed() {
        return messageAccountPasswordsDoNotMatch.isDisplayed();
    }

}
