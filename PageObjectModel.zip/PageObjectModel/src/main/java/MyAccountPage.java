import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAccountPage extends BasePage{
    @FindBy(xpath = "//input[@type='submit']")
    private WebElement buttonCalculate;

    @FindBy(xpath = "//ul[@class='nav navbar-nav navbar-right']/a")
    private WebElement linkLogout;


    public MyAccountPage(WebDriver driver) {
        super(driver);
    }

    public WebElement getButtonCalculate() {
        return buttonCalculate;
    }

    public boolean isButtonCalculateDisplayed() {
        return buttonCalculate.isDisplayed();
    }

    public WebElement getLinkLogout() {
        return linkLogout;
    }

    public boolean isLinkLogoutDisplayed() {
        return linkLogout.isDisplayed();
    }

    public void clickLinkLogout() {
        linkLogout.click();
    }

}
