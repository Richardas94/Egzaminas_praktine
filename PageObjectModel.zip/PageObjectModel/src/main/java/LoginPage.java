import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends BasePage {

    @FindBy(xpath = "//input[@name='username']")
    private WebElement inputUsername;

    @FindBy(xpath = "//input[@name='password']")
    private WebElement inputPassword;

    @FindBy(xpath = "//button[@type='submit']")
    private WebElement buttonLogin;

    @FindBy(xpath = "//a[@href='/registruoti']")
    private WebElement linkCreateNewAccount;

    @FindBy(xpath = "//div//span[2]")
    private WebElement messageLoginFailed;

    @FindBy(xpath = "//h1")
    WebElement headerOfApplication;


    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public void enterInputUsername(String username) {
        inputUsername.sendKeys(username);
    }

    public void enterInputPassword(String password) {
        inputPassword.sendKeys(password);
    }

    public void clickButtonLogin() {
        buttonLogin.click();
    }

    public void clickLinkCreateNewAccount() {
        linkCreateNewAccount.click();
    }

    public WebElement getMessageLoginFailed() {
        return messageLoginFailed;
    }

    public boolean isMessageLoginFailedDisplayed() {
        return messageLoginFailed.isDisplayed();
    }

    public WebElement getHeaderOfApplication() {
        return headerOfApplication;
    }

    public boolean isHeaderOfApplicationDisplayed(){
        return headerOfApplication.isDisplayed();
    }





}
